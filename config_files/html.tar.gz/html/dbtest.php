<?php
$con = new PDO('localhost','user','password');
if(!$con){
	die("failed".mysqli_error());
}else{
	echo "db connect success";
}

