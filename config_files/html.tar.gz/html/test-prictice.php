<!DOCTYPE html>
<html>
<head>
	<meta charst="utf-8">
	<title>Php test</title>
</head>

<body>

<?php
$a=10;
$b=10;
echo $a+$b;
echo '<br>';
const THE_VALUE = 100;
echo THE_VALUE;

function print_hello_world() {
	echo 'hello world';
}

echo '<br>';
print_hello_world();

function print_hello($name) {
	echo 'hello'.$name.'<br>';
}

echo '<br>';
print_hello(' php');
echo '中文测试'.'<br>';

$str='hello word';
echo strpos($str,'w').'<br>';


echo time();
echo '<br>';
echo date('Y-m-d [H:i:s]').'<br>';

echo "<a href='https://www.ip.cn/' target=blank> quarry ip address</a><br>";
echo file_get_contents('/tmp/file.txt');
echo `curl www.baidu.com`;



?>


</body>
</html>
